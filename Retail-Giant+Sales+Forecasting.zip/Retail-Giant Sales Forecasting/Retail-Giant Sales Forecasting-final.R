
### Business Understanding:

# Global Mart is an online store super giant having worldwide operations. 
# It takes orders and delivers across the globe and deals with all the major product
# categories - consumer, corporate & home office.

### Problem Statement
# We want to finalise the plan for the next 6 months that would help us manage
# the revenue and inventory accordingly.

## AIM
# The aim is to forecast the sales and the demand for the next 6 months

### Data Understanding:
# The data currently has the transaction level data, where each row represents a particular order
# made on the online store. There are 24 attributes related to each such transaction. The Market 
# attribute has 7-factor levels representing the geographical market sector that the customer
# belongs to. The Segment attribute tells which of the 3 segments that customer belongs to.


# loading the required libraries 
library(dplyr)
library(graphics)
library(forecast)
library(tseries)
library(tidyr) 
library(hash)
library(FinCal)
library(ggplot2)

GS <- read.csv("Global Superstore.csv", header = TRUE)
summary(GS)
typeof(GS$Order.Date)

### Data Preparation:

# checking for missing values in Sales, Quantity and Profit columns
sum(is.na(GS$Sales))
sum(is.na(GS$Quantity))
sum(is.na(GS$Profit))
# None have NA or missing values

# Separating date column to form monthwise date only(removing Day from the date)
GS <- separate(GS, Order.Date, into = c('Day','Month','Year'),sep = '-')
GS$Day <- 01
GS <- unite(GS, Date, c(Day,Month, Year),sep='-')
#GS$Date <- as.Date(GS$Date, format = "%m-%Y")

# Creating the segments
Corporate_Africa <- filter(GS,GS$Market == 'Africa',GS$Segment == 'Corporate')
Corporate_APAC <- filter(GS,GS$Market == 'APAC',GS$Segment == 'Corporate')
Corporate_Canada <- filter(GS,GS$Market == 'Canada',GS$Segment == 'Corporate')
Corporate_EMEA <- filter(GS,GS$Market == 'EMEA',GS$Segment == 'Corporate')
Corporate_EU <- filter(GS,GS$Market == 'EU',GS$Segment == 'Corporate')
Corporate_LATAM <- filter(GS,GS$Market == 'LATAM',GS$Segment == 'Corporate')
Corporate_US <- filter(GS,GS$Market == 'US',GS$Segment == 'Corporate')
Consumer_Africa <- filter(GS,GS$Market == 'Africa',GS$Segment == 'Consumer')
Consumer_APAC <- filter(GS,GS$Market == 'APAC',GS$Segment == 'Consumer')
Consumer_Canada <- filter(GS,GS$Market == 'Canada',GS$Segment == 'Consumer')
Consumer_EMEA <- filter(GS,GS$Market == 'EMEA',GS$Segment == 'Consumer')
Consumer_EU <- filter(GS,GS$Market == 'EU',GS$Segment == 'Consumer')
Consumer_LATAM <- filter(GS,GS$Market == 'LATAM',GS$Segment == 'Consumer')
Consumer_US <- filter(GS,GS$Market == 'US',GS$Segment == 'Consumer')
Home_Office_Africa <- filter(GS,GS$Market == 'Africa',GS$Segment == 'Home Office')
Home_Office_APAC <- filter(GS,GS$Market == 'APAC',GS$Segment == 'Home Office')
Home_Office_Canada <- filter(GS,GS$Market == 'Canada',GS$Segment == 'Home Office')
Home_Office_EMEA <- filter(GS,GS$Market == 'EMEA',GS$Segment == 'Home Office')
Home_Office_EU <- filter(GS,GS$Market == 'EU',GS$Segment == 'Home Office')
Home_Office_LATAM <- filter(GS,GS$Market == 'LATAM',GS$Segment == 'Home Office')
Home_Office_US <- filter(GS,GS$Market == 'US',GS$Segment == 'Home Office')



# Aggregating the Sales, Profit and Quantity Date wise
# Converting the date to appropriate format and Sorting the data as per date in Ascending order
aggr_sqp <- function(df) {
  x <- aggregate(cbind(Sales,Quantity,Profit) ~ Date, data = df, sum)
  x <- x[order(as.Date(x$Date, format="%d-%m-%Y")),]
  return(x)
}

Corporate_Africa <-aggr_sqp(Corporate_Africa)
Corporate_APAC <-aggr_sqp(Corporate_APAC)
Corporate_Canada <-aggr_sqp(Corporate_Canada)
Corporate_EMEA <-aggr_sqp(Corporate_EMEA)
Corporate_EU <-aggr_sqp(Corporate_EU)
Corporate_LATAM <-aggr_sqp(Corporate_LATAM)
Corporate_US <-aggr_sqp(Corporate_US)
Consumer_Africa <-aggr_sqp(Consumer_Africa)
Consumer_APAC <-aggr_sqp(Consumer_APAC)
Consumer_Canada <-aggr_sqp(Consumer_Canada)
Consumer_EMEA <-aggr_sqp(Consumer_EMEA)
Consumer_EU <-aggr_sqp(Consumer_EU)
Consumer_LATAM <-aggr_sqp(Consumer_LATAM)
Consumer_US <-aggr_sqp(Consumer_US)
Home_Office_Africa <-aggr_sqp(Home_Office_Africa)
Home_Office_APAC <-aggr_sqp(Home_Office_APAC)
Home_Office_Canada <-aggr_sqp(Home_Office_Canada)
Home_Office_EMEA <-aggr_sqp(Home_Office_EMEA)
Home_Office_EU <-aggr_sqp(Home_Office_EU)
Home_Office_LATAM <-aggr_sqp(Home_Office_LATAM)
Home_Office_US <-aggr_sqp(Home_Office_US)

#######################################

## Now We have 48 months wise 21 segments. 
## Plotting Time series for Profit for all the 21 segments for 48 months
## Discarding the data for Canada Region as it is not coonsistent for 48 months and have data for
## less than 48 months
par(mfrow=c(3,3))
plot(ts(Corporate_Africa$Profit))
plot(ts(Corporate_APAC$Profit))
plot(ts(Corporate_EMEA$Profit))
plot(ts(Corporate_EU$Profit))
plot(ts(Corporate_LATAM$Profit))
plot(ts(Corporate_US$Profit))
plot(ts(Consumer_Africa$Profit))
plot(ts(Consumer_APAC$Profit))
plot(ts(Consumer_EMEA$Profit))
plot(ts(Consumer_EU$Profit))
plot(ts(Consumer_LATAM$Profit))
plot(ts(Consumer_US$Profit))
plot(ts(Home_Office_Africa$Profit))
plot(ts(Home_Office_APAC$Profit))
plot(ts(Home_Office_EMEA$Profit))
plot(ts(Home_Office_EU$Profit))
plot(ts(Home_Office_LATAM$Profit))
plot(ts(Home_Office_US$Profit))

## Creating a new Dataframe for the coefficient of variation for each segment
df_1<-data.frame('Corporate_Africa',sd(Corporate_Africa$Profit)/mean(Corporate_Africa$Profit),sum(Corporate_Africa$Profit))
df_2<-data.frame('Corporate_APAC',sd(Corporate_APAC$Profit)/mean(Corporate_APAC$Profit),sum(Corporate_APAC$Profit))
df_3<-data.frame('Corporate_Canada',sd(Corporate_Canada$Profit)/mean(Corporate_Canada$Profit),sum(Corporate_Canada$Profit))
df_4<-data.frame('Corporate_EMEA',sd(Corporate_EMEA$Profit)/mean(Corporate_EMEA$Profit),sum(Corporate_EMEA$Profit))
df_5<-data.frame('Corporate_EU',sd(Corporate_EU$Profit)/mean(Corporate_EU$Profit),sum(Corporate_EU$Profit))
df_6<-data.frame('Corporate_LATAM',sd(Corporate_LATAM$Profit)/mean(Corporate_LATAM$Profit),sum(Corporate_LATAM$Profit))
df_7<-data.frame('Corporate_US',sd(Corporate_US$Profit)/mean(Corporate_US$Profit),sum(Corporate_US$Profit))
df_8<-data.frame('Consumer_Africa',sd(Consumer_Africa$Profit)/mean(Consumer_Africa$Profit),sum(Consumer_Africa$Profit))
df_9<-data.frame('Consumer_APAC',sd(Consumer_APAC$Profit)/mean(Consumer_APAC$Profit),sum(Consumer_APAC$Profit))
df_10<-data.frame('Consumer_Canada',sd(Consumer_Canada$Profit)/mean(Consumer_Canada$Profit),sum(Consumer_Canada$Profit))
df_11<-data.frame('Consumer_EMEA',sd(Consumer_EMEA$Profit)/mean(Consumer_EMEA$Profit),sum(Consumer_EMEA$Profit))
df_12<-data.frame('Consumer_EU',sd(Consumer_EU$Profit)/mean(Consumer_EU$Profit),sum(Consumer_EU$Profit))
df_13<-data.frame('Consumer_LATAM',sd(Consumer_LATAM$Profit)/mean(Consumer_LATAM$Profit),sum(Consumer_LATAM$Profit))
df_14<-data.frame('Consumer_US',sd(Consumer_US$Profit)/mean(Consumer_US$Profit),sum(Consumer_US$Profit))
df_15<-data.frame('Home_Office_Africa',sd(Home_Office_Africa$Profit)/mean(Home_Office_Africa$Profit),sum(Home_Office_Africa$Profit))
df_16<-data.frame('Home_Office_APAC',sd(Home_Office_APAC$Profit)/mean(Home_Office_APAC$Profit),sum(Home_Office_APAC$Profit))
df_17<-data.frame('Home_Office_Canada',sd(Home_Office_Canada$Profit)/mean(Home_Office_Canada$Profit),sum(Home_Office_Canada$Profit))
df_18<-data.frame('Home_Office_EMEA',sd(Home_Office_EMEA$Profit)/mean(Home_Office_EMEA$Profit),sum(Home_Office_EMEA$Profit))
df_19<-data.frame('Home_Office_EU',sd(Home_Office_EU$Profit)/mean(Home_Office_EU$Profit),sum(Home_Office_EU$Profit))
df_20<-data.frame('Home_Office_LATAM',sd(Home_Office_LATAM$Profit)/mean(Home_Office_LATAM$Profit),sum(Home_Office_LATAM$Profit))
df_21<-data.frame('Home_Office_US',sd(Home_Office_US$Profit)/mean(Home_Office_US$Profit),sum(Home_Office_US$Profit))
names(df_1)<-c('Region','Coeff','Total Profit')
names(df_2)<-c('Region','Coeff','Total Profit')
names(df_3)<-c('Region','Coeff','Total Profit')
names(df_4)<-c('Region','Coeff','Total Profit')
names(df_5)<-c('Region','Coeff','Total Profit')
names(df_6)<-c('Region','Coeff','Total Profit')
names(df_7)<-c('Region','Coeff','Total Profit')
names(df_8)<-c('Region','Coeff','Total Profit')
names(df_9)<-c('Region','Coeff','Total Profit')
names(df_10)<-c('Region','Coeff','Total Profit')
names(df_11)<-c('Region','Coeff','Total Profit')
names(df_12)<-c('Region','Coeff','Total Profit')
names(df_13)<-c('Region','Coeff','Total Profit')
names(df_14)<-c('Region','Coeff','Total Profit')
names(df_15)<-c('Region','Coeff','Total Profit')
names(df_16)<-c('Region','Coeff','Total Profit')
names(df_17)<-c('Region','Coeff','Total Profit')
names(df_18)<-c('Region','Coeff','Total Profit')
names(df_19)<-c('Region','Coeff','Total Profit')
names(df_20)<-c('Region','Coeff','Total Profit')
names(df_21)<-c('Region','Coeff','Total Profit')
coeff_DF <- rbind(df_1,df_2,df_3,df_4,df_5,df_6,df_7,df_8,df_9,df_10,df_11,df_12,df_13,df_14,df_15,df_16,df_17,df_18,df_19,df_20,df_21)
remove(df_1,df_2,df_3,df_4,df_5,df_6,df_7,df_8,df_9,df_10,df_11,df_12,df_13,df_14,df_15,df_16,df_17,df_18,df_19,df_20,df_21)


# Two top most consistently profitable segments are Consumer_EU and Consumer_APAC
# based on the lowest coefficient of variation and also looking into the time series for the
# two segments

##################
# For APAC Region #
#Seperating test and train data for Consumer_APAC 
# 6 months data is used for evaluation
Consumer_APAC$Num <- c(1:nrow(Consumer_APAC))

APACConTest <- Consumer_APAC[c((nrow(Consumer_APAC)-5):nrow(Consumer_APAC)),]
APACConTrain <- Consumer_APAC[c(1:(nrow(Consumer_APAC)-6)),]
#View(Consumer_APAC)
# Converting the Sale and Quantity to a time series data for both these segments

# for Consumer APAC
ts_sales_cap <- ts(APACConTrain$Sales)
ts_qty_cap <- ts(APACConTrain$Quantity)

# Plotting the time series of each component of each segment
par(mfrow=c(2,1))
plot(ts_sales_cap)
plot(ts_qty_cap)


#smoothening the series
#using w = 1
ts_sales_cap_smooth <- stats::filter(ts_sales_cap, 
                                           filter=rep(1/(2*1+1),(2*1+1)), 
                                           method='convolution', sides=2)


#Smoothing left end of the time series

diff <- ts_sales_cap_smooth[1+2] - ts_sales_cap_smooth[1+1]
for (i in seq(1,1,-1)) {
  ts_sales_cap_smooth[i] <- ts_sales_cap_smooth[i+1] - diff
}

#Smoothing right end of the time series

n <- length(ts_sales_cap)
diff <- ts_sales_cap_smooth[n-1] - ts_sales_cap_smooth[n-1-1]
for (i in seq(n-1+1, n)) {
  ts_sales_cap_smooth[i] <- ts_sales_cap_smooth[i-1] + diff
}



#Plot the smoothed time series
plot(ts_sales_cap)
lines(ts_sales_cap_smooth, col="blue", lwd=2)

#filter using 
cols <- c("red", "yellow", "green", "black")
alphas <- c(0.02, 0.1,0.5, 0.8)
labels <- c(paste("alpha =", alphas), "Original")
for (i in seq(1,length(alphas))) {
  smoothedseries <- HoltWinters(ts_sales_cap, alpha=alphas[i],
                                beta=FALSE, gamma=FALSE)
  
  lines(fitted(smoothedseries)[,1], col=cols[i], lwd=2)
}
legend("topleft", labels, col=cols, lwd=2)
#using the filter()  smoothning since it gives better fit

#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe
timevals_in <- APACConTrain$Num
APACConSalesTrain_df <- as.data.frame(cbind(timevals_in, as.vector(ts_sales_cap_smooth)))
colnames(APACConSalesTrain_df) <- c('Month', 'Sales')


#Now, let's fit a combination of multiplicative and additive model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function
APACConSales_lmfit <- lm(APACConSalesTrain_df$Sales ~ sin(0.5*APACConSalesTrain_df$Month) *
                           poly(APACConSalesTrain_df$Month,2) 
                         + cos(0.5*APACConSalesTrain_df$Month) * 
                           poly(APACConSalesTrain_df$Month,2)
                         + sin(0.05*APACConSalesTrain_df$Month)*
                           APACConSalesTrain_df$Month, 
                         data=APACConSalesTrain_df)

summary(APACConSales_lmfit)
accuracy(APACConSales_lmfit)

##############################################################################################
### Need to confirm on this model
#Changed LMFit after seeing Mape Value
APACConSales_lmfit <- lm(Sales ~ 
                           cos(0.5*Month) * I(Month^2) 
                         - I(Month^2)
                         +sin(0.5*Month)
                         - cos(0.5*Month)
                         + Month, data=APACConSalesTrain_df) 
summary(APACConSales_lmfit)
accuracy(APACConSales_lmfit)
AMACConSales_Predict <- predict(APACConSales_lmfit, Month=timevals_in)
plot(AMACConSales_Predict)
lines(timevals_in, AMACConSales_Predict, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred_APACConSales <- ts_sales_cap-AMACConSales_Predict
par(mfrow=c(1,1))
plot(local_pred_APACConSales, col='red', type = "l")
acf(local_pred_APACConSales)
acf(local_pred_APACConSales, type="partial")
armafit_APACConSales <- auto.arima(local_pred_APACConSales)

tsdiag(armafit_APACConSales)
armafit_APACConSales


#We'll check if the residual series is white noise

resi_APACConSales <- local_pred_APACConSales-fitted(armafit_APACConSales)

adf.test(resi_APACConSales,alternative = "stationary")
kpss.test(resi_APACConSales)

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months

timevals_out <- APACConTest$Num
global_pred_out <- predict(APACConSales_lmfit,data.frame(Month =timevals_out))

fcast <- global_pred_out
MAPE_class_dec <- accuracy(fcast,APACConTest[,2])[5]
MAPE_class_dec
#26.70807 which is good


#So, that was classical decomposition, now let's do an ARIMA fit

APACCon_Salesautoarima <- auto.arima(ts_sales_cap_smooth)
APACCon_Salesautoarima
tsdiag(APACCon_Salesautoarima)
plot(APACCon_Salesautoarima$x, col="black")
lines(fitted(APACCon_Salesautoarima), col="red")

#Again, let's check if the residual series is white noise

APACCon_sales_resi_auto_arima <- ts_sales_cap_smooth - fitted(APACCon_Salesautoarima)

adf.test(APACCon_sales_resi_auto_arima,alternative = "stationary")
kpss.test(APACCon_sales_resi_auto_arima)

#Also, let's evaluate the model using MAPE
APACCon_sales_fcast_auto_arima <- predict(APACCon_Salesautoarima, n.ahead = 6)

APACCon_sales_MAPE_auto_arima <- accuracy(APACCon_sales_fcast_auto_arima$pred,APACConTest[,2])[5]
APACCon_sales_MAPE_auto_arima
#27.3386

#ploting the predictions along with original values

auto_arima_pred <- c(fitted(APACCon_Salesautoarima),ts(APACCon_sales_fcast_auto_arima$pred))
plot(auto_arima_pred, col = "black")
lines(auto_arima_pred, col = "red")

#################################################################################################

#Modeling APAC Con Qty

#smoothening the series
#using w = 1
ts_qty_cap_Smooth <- stats::filter(ts_qty_cap, 
                                         filter=rep(1/(2*1+1),(2*1+1)), 
                                         method='convolution', sides=2)


#Smoothing left end of the time series

diff <- ts_qty_cap_Smooth[1+2] - ts_qty_cap_Smooth[1+1]
for (i in seq(1,1,-1)) {
  ts_qty_cap_Smooth[i] <- ts_qty_cap_Smooth[i+1] - diff
}

#Smoothing right end of the time series

n <- length(ts_qty_cap)
diff <- ts_qty_cap_Smooth[n-1] - ts_qty_cap_Smooth[n-1-1]
for (i in seq(n-1+1, n)) {
  ts_qty_cap_Smooth[i] <- ts_qty_cap_Smooth[i-1] + diff
}

#Plot the smoothed time series
plot(ts_qty_cap)
#timevals_in <- indata$Month
lines(ts_qty_cap_Smooth, col="blue", lwd=2)

#filter using 
cols <- c("red", "yellow", "green", "black")
alphas <- c(0.02, 0.1,0.5, 0.8)
labels <- c(paste("alpha =", alphas), "Original")
for (i in seq(1,length(alphas))) {
  smoothedseries <- HoltWinters(ts_qty_cap, alpha=alphas[i],
                                beta=FALSE, gamma=FALSE)
  
  lines(fitted(smoothedseries)[,1], col=cols[i], lwd=2)
}
legend("topleft", labels, col=cols, lwd=2)
#using the filter()  smoothning since it gives better fit

#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe
timevals_in <- APACConTrain$Num
AMACConQtysmoothed_df <- as.data.frame(cbind(timevals_in, as.vector(ts_qty_cap_Smooth)))
colnames(AMACConQtysmoothed_df) <- c('month', 'Qty')


#Now, let's fit a multiplicative and additive model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function
lmfit_q <- lm(Qty ~ 
                + sin(0.5*month) * month
              + sin(0.5*month) * I(month^2)
              + cos(0.5*month) * I(month^3)
              - cos(0.5*month) 
              - sin(0.5*month)
              - I(month^2)
              - I(month^3)
              + month, data=AMACConQtysmoothed_df)


summary(lmfit_q)
accuracy(lmfit_q)
AMACConQtyPredict <- predict(lmfit_q, Month=timevals_in)
plot(AMACConQtyPredict)
lines(timevals_in, AMACConQtyPredict, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred_APACConQty <- ts_qty_cap-AMACConQtyPredict
plot(local_pred_APACConQty, col='red', type = "l")
acf(local_pred_APACConQty)
acf(local_pred_APACConQty, type="partial")
armafit_APACConQty <- auto.arima(local_pred_APACConQty)

tsdiag(armafit_APACConQty)
armafit_APACConQty

#We'll check if the residual series is white noise

resi_APACConQty <- local_pred_APACConQty-fitted(armafit_APACConQty)

adf.test(resi_APACConQty,alternative = "stationary")
kpss.test(resi_APACConQty)

#evaluating the model using MAPE
#First, let's make a prediction for the last 6 months

APAConQty_timevals_out <- APACConTest$Num
APACConQty_global_pred_out <- predict(lmfit_q,data.frame(month =APAConQty_timevals_out))

fcast <- APACConQty_global_pred_out
APACConQty_MAPE_class_dec <- accuracy(fcast,APACConTest[,2])[5]
APACConQty_MAPE_class_dec
# MAPE - 98.74806


#So, that was classical decomposition, now let's do an ARIMA fit

APACCon_Qtyautoarima <- auto.arima(ts_qty_cap_Smooth)
APACCon_Qtyautoarima
tsdiag(APACCon_Qtyautoarima)
plot(APACCon_Qtyautoarima$x, col="black")
lines(fitted(APACCon_Qtyautoarima), col="red")

#Again, let's check if the residual series is white noise

APACCon_Qty_resi_auto_arima <- ts_qty_cap_Smooth - fitted(APACCon_Qtyautoarima)

adf.test(APACCon_Qty_resi_auto_arima,alternative = "stationary")
kpss.test(APACCon_Qty_resi_auto_arima)

#Also, let's evaluate the model using MAPE
APACCon_Qty_fcast_auto_arima <- predict(APACCon_Qtyautoarima, n.ahead = 6)

APACCon_Qty_MAPE_auto_arima <- accuracy(APACCon_Qty_fcast_auto_arima$pred,APACConTest[,2])[5]
APACCon_Qty_MAPE_auto_arima

#ploting the predictions along with original values

APACConQty_auto_arima_pred <- c(fitted(APACCon_Qtyautoarima),ts(APACCon_Qty_fcast_auto_arima$pred))
plot(APACConQty_auto_arima_pred, col = "black")
lines(APACConQty_auto_arima_pred, col = "red")


###############
# For EU region

#Seperating test and train data for Consumer_EU 
# 6 months data is used for evaluation
Consumer_EU$Num <- c(1:nrow(Consumer_EU))
EUConTest <- Consumer_EU[c((nrow(Consumer_EU)-5):nrow(Consumer_EU)),]
EUConTrain <- Consumer_EU[c(1:(nrow(Consumer_EU)-6)),]

ts_sales_ceu <- ts(EUConTrain$Sales)
ts_qty_ceu <- ts(EUConTrain$Quantity)

# Plotting the time series of each component of each segment
par(mfrow=c(2,1))
plot(ts_sales_ceu)
plot(ts_qty_ceu)

#smoothening the series
#smoothening the series
#using w = 1
ts_sales_ceu_Smooth <- stats::filter(ts_sales_ceu, 
                                         filter=rep(1/(2*1+1),(2*1+1)), 
                                         method='convolution', sides=2)


#Smoothing left end of the time series

diff <- ts_sales_ceu_Smooth[1+2] - ts_sales_ceu_Smooth[1+1]
for (i in seq(1,1,-1)) {
  ts_sales_ceu_Smooth[i] <- ts_sales_ceu_Smooth[i+1] - diff
}

#Smoothing right end of the time series

n <- length(ts_sales_ceu)
diff <- ts_sales_ceu_Smooth[n-1] - ts_sales_ceu_Smooth[n-1-1]
for (i in seq(n-1+1, n)) {
  ts_sales_ceu_Smooth[i] <- ts_sales_ceu_Smooth[i-1] + diff
}

#Plot the smoothed time series
plot(ts_sales_ceu)
lines(ts_sales_ceu_Smooth, col="blue", lwd=2)

#filter using 
cols <- c("red", "yellow", "green", "black")
alphas <- c(0.02, 0.1,0.5, 0.8)
labels <- c(paste("alpha =", alphas), "Original")
for (i in seq(1,length(alphas))) {
  smoothedseries <- HoltWinters(ts_sales_ceu, alpha=alphas[i],
                                beta=FALSE, gamma=FALSE)
  
  lines(fitted(smoothedseries)[,1], col=cols[i], lwd=2)
}
legend("topleft", labels, col=cols, lwd=2)

#using the lmfit()  smoothning since it gives better fit
#EUConSalesTimeserSmooth <- HoltWinters(EUConSalesTimeser, alpha=0.5,beta=FALSE, gamma=FALSE)

#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe
timevals_in <- EUConTrain$Num
EUConSalessmootheddf <- as.data.frame(cbind(timevals_in, as.vector(ts_sales_ceu_Smooth)))
colnames(EUConSalessmootheddf) <- c('Month','Sales')


#Now, let's fit a combination of multiplicative and additive model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function
EUConSales_lmfit <-  lm(Sales ~ poly(Month,3) 
                        +  cos(0.5*Month)
                        +   sin(0.5*Month)
                        +    sin(0.5*Month) * Month
                        + Month, data=EUConSalessmootheddf)
summary(EUConSales_lmfit)
accuracy(EUConSales_lmfit)
EUConSalesPredict <- predict(EUConSales_lmfit, Month=timevals_in)
plot(EUConSalesPredict)
lines(timevals_in, EUConSalesPredict, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred_EUConSales <- ts_sales_ceu-EUConSalesPredict
plot(local_pred_EUConSales, col='red', type = "l")
acf(local_pred_EUConSales)
acf(local_pred_EUConSales, type="partial")
armafit_EUConSales <- auto.arima(local_pred_EUConSales)

tsdiag(armafit_EUConSales)
armafit_EUConSales


#We have just pure noise in local_pre_EUConSales

#checking if the residual series is white noise

resi_EUConSales <- local_pred_EUConSales-fitted(armafit_EUConSales)

adf.test(resi_EUConSales,alternative = "stationary")
kpss.test(resi_EUConSales)

#evaluating the model using MAPE
#First, let's make a prediction for the last 6 months

timevals_out <- EUConTest$Num
global_pred_out <- predict(EUConSales_lmfit,data.frame(Month =timevals_out))

fcast <- global_pred_out
MAPE_class_dec <- accuracy(fcast,EUConTest[,2])[5]
MAPE_class_dec
#23.28411 which is good


#So, that was classical decomposition, now let's do an ARIMA fit

EUCon_Salesautoarima <- auto.arima(ts_sales_ceu_Smooth)
EUCon_Salesautoarima
tsdiag(EUCon_Salesautoarima)
plot(EUCon_Salesautoarima$x, col="black")
lines(fitted(EUCon_Salesautoarima), col="red")

#Again, let's check if the residual series is white noise

EUCon_sales_resi_auto_arima <- ts_sales_ceu_Smooth - fitted(EUCon_Salesautoarima)

adf.test(EUCon_sales_resi_auto_arima,alternative = "stationary")
kpss.test(EUCon_sales_resi_auto_arima)

#Also, let's evaluate the model using MAPE
EUCon_sales_fcast_auto_arima <- predict(EUCon_Salesautoarima, n.ahead = 6)

EUCon_sales_MAPE_auto_arima <- accuracy(EUCon_sales_fcast_auto_arima$pred,EUConTest[,2])[5]
EUCon_sales_MAPE_auto_arima
#31.04337

#ploting the predictions along with original values

auto_arima_pred <- c(fitted(EUCon_Salesautoarima),ts(EUCon_sales_fcast_auto_arima$pred))
plot(auto_arima_pred, col = "black")
lines(auto_arima_pred, col = "red")





#####
#Modeling EU Con Qty

#smoothening the series
#using w = 1
ts_qty_ceu_smooth <- stats::filter(ts_qty_ceu, 
                                       filter=rep(1/(2*1+1),(2*1+1)), 
                                       method='convolution', sides=2)


#Smoothing left end of the time series

diff <- ts_qty_ceu_smooth[1+2] - ts_qty_ceu_smooth[1+1]
for (i in seq(1,1,-1)) {
  ts_qty_ceu_smooth[i] <- ts_qty_ceu_smooth[i+1] - diff
}

#Smoothing right end of the time series

n <- length(ts_qty_ceu)
diff <- ts_qty_ceu_smooth[n-1] - ts_qty_ceu_smooth[n-1-1]
for (i in seq(n-1+1, n)) {
  ts_qty_ceu_smooth[i] <- ts_qty_ceu_smooth[i-1] + diff
}

#Plot the smoothed time series
plot(ts_qty_ceu)

#timevals_in <- indata$Month
lines(ts_qty_ceu_smooth, col="blue", lwd=2)

#filter using 
cols <- c("red", "yellow", "green", "black")
alphas <- c(0.02, 0.1,0.5, 0.8)
labels <- c(paste("alpha =", alphas), "Original")
for (i in seq(1,length(alphas))) {
  smoothedseries <- HoltWinters(ts_qty_ceu, alpha=alphas[i],
                                beta=FALSE, gamma=FALSE)
  
  lines(fitted(smoothedseries)[,1], col=cols[i], lwd=2)
}
legend("topleft", labels, col=cols, lwd=2)
#using the filter()  smoothning since it gives better fit

#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe
timevals_in <- EUConTrain$Num
EUConQtysmootheddf <- as.data.frame(cbind(timevals_in, as.vector(ts_qty_ceu_smooth)))
colnames(EUConQtysmootheddf) <- c('month', 'Qty')


#Now, let's fit a combination of multiplicative and additive model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function
lmfit_q <- lm(Qty ~ 
                + sin(0.5*month) * month
              + sin(0.5*month) * I(month^2)
              + cos(0.5*month) * I(month^3)
              - cos(0.5*month) 
              - sin(0.5*month)
              - I(month^2)
              - I(month^3)
              + month, data=EUConQtysmootheddf)


summary(lmfit_q)
accuracy(lmfit_q)
EUConQtyPredict <- predict(lmfit_q, Month=timevals_in)
plot(EUConQtyPredict)
lines(timevals_in, EUConQtyPredict, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred_EUConQty <- ts_qty_ceu-EUConQtyPredict
plot(local_pred_EUConQty, col='red', type = "l")
acf(local_pred_EUConQty)
acf(local_pred_EUConQty, type="partial")
armafit_EUConQty <- auto.arima(local_pred_EUConQty)

tsdiag(armafit_EUConQty)
armafit_EUConQty

#We have just pure noise in local_pre_EUConQty

#checking if the residual series is white noise

resi_EUConQty <- local_pred_EUConQty-fitted(armafit_EUConQty)

adf.test(resi_EUConQty,alternative = "stationary")
kpss.test(resi_EUConQty)

#evaluating the model using MAPE
#First, let's make a prediction for the last 6 months

EUonQty_timevals_out <- EUConTest$Num
EUConQty_global_pred_out <- predict(lmfit_q,data.frame(month =EUonQty_timevals_out))

fcast <- EUConQty_global_pred_out
EUConQty_MAPE_class_dec <- accuracy(fcast,EUConTest[,2])[5]
EUConQty_MAPE_class_dec
#98.71582


#So, that was classical decomposition, now let's do an ARIMA fit

EUCon_Qtyautoarima <- auto.arima(ts_qty_ceu_smooth)
EUCon_Qtyautoarima
tsdiag(EUCon_Qtyautoarima)
plot(EUCon_Qtyautoarima$x, col="black")
lines(fitted(EUCon_Qtyautoarima), col="red")

#Again, let's check if the residual series is white noise

EUCon_Qty_resi_auto_arima <- ts_qty_ceu_smooth - fitted(EUCon_Qtyautoarima)

adf.test(EUCon_Qty_resi_auto_arima,alternative = "stationary")
kpss.test(EUCon_Qty_resi_auto_arima)

#Also, let's evaluate the model using MAPE
EUCon_Qty_fcast_auto_arima <- predict(EUCon_Qtyautoarima, n.ahead = 6)

EUCon_Qty_MAPE_auto_arima <- accuracy(EUCon_Qty_fcast_auto_arima$pred,EUConTest[,2])[5]
EUCon_Qty_MAPE_auto_arima

#ploting the predictions along with original values

EUConQty_auto_arima_pred <- c(fitted(EUCon_Qtyautoarima),ts(EUCon_Qty_fcast_auto_arima$pred))
plot(EUConQty_auto_arima_pred, col = "black")
lines(EUConQty_auto_arima_pred, col = "red")

